#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include<QString>
#include"Caculator.h"
#include<QDockWidget>
Calculator cal;
 int flag=0;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
   //b = new QPushButton(this);
    ui->setupUi(this);
    setWindowTitle(tr("Calculator"));

//    QDockWidget *dock=new QDockWidget(this);
//    addDockWidget(Qt::RightDockWidgetArea,dock);//建立浮动窗口
    //直接在ui中添加
    //ui->dockWidget->
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{ s+="1";
  ui->lineEdit->setText(s);
}


void MainWindow::on_pushButton_2_clicked()
{ s+="2";
     // ui->pushButton_2->setText("niubi");
     ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_3_clicked()
{

    s+="3";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_4_clicked()
{
    s+="4";
    ui->lineEdit->setText(s);
}


void MainWindow::on_pushButton_5_clicked()
{
    s+="5";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_6_clicked()
{
    s+="6";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_7_clicked()
{
    s+="7";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_8_clicked()
{
    s+="8";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_9_clicked()
{
    s+="9";
    ui->lineEdit->setText(s);
}




void MainWindow::on_pushButton_10_clicked()
{
    s+="+";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_12_clicked()//按下等于，进行计算
{   s+="=";
    ui->lineEdit->setText(s);
    ui->textEdit->append(s);//记住内存
    string exp= s.toStdString();
        ui->lineEdit->clear();
        //exp=cal.doIt(exp);
        s=QString::number(cal.doIt(exp));
        if(s=="0"){
            ui->lineEdit->setText("input error");
             ui->textEdit->append("input error");
             s.clear();
        }
        else{
        ui->lineEdit->setText(s);
        }
        if(s!="0"){
        ui->textEdit->append(s);
        }

}

void MainWindow::on_pushButton_11_clicked()
{   if (flag==0) {
        ui->pushButton_16->setText("arcsin");
        ui->pushButton_22->setText("arccos");
        ui->pushButton_23->setText("arctan");
        ui->pushButton_24->setText("X^2");
                flag=1;
    }
    else if (flag==1){
        ui->pushButton_16->setText("sin");
        ui->pushButton_22->setText("cos");
        ui->pushButton_23->setText("tan");
        ui->pushButton_24->setText("sqrt");
                flag=0;
    }
}




void MainWindow::on_pushButton_13_clicked()
{
    s+="(";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_14_clicked()
{
    s+=")";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_16_clicked()
{if (flag==0){
    s+="sin";
    ui->lineEdit->setText(s);
    }
    else if(flag==1){
        s+="arcsin";
        ui->lineEdit->setText(s);
    }
}

void MainWindow::on_pushButton_15_clicked()
{
    s="";
    ui->lineEdit->setText("0");
}

void MainWindow::on_pushButton_20_clicked()
{
    s+=".";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_17_clicked()
{
    s+="-";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_18_clicked()
{
    s+="*";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_19_clicked()
{
    s+="/";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_21_clicked()
{
    s+="0";
    ui->lineEdit->setText(s);
}

void MainWindow::on_pushButton_22_clicked()
{if (flag==0){
    s+="cos";
    ui->lineEdit->setText(s);
    }
    else if (flag==1){
        s+="arccos";
        ui->lineEdit->setText(s);
    }
}

void MainWindow::on_pushButton_23_clicked()
{if (flag==0){
        s+="tan";
        ui->lineEdit->setText(s);
        }
        else if (flag==1){
            s+="arctan";
            ui->lineEdit->setText(s);
        }
}

void MainWindow::on_pushButton_24_clicked()
{
    if (flag==0){
        s+="sqrt";
        ui->lineEdit->setText(s);
        }
        else if (flag==1){
            s+="square";
            ui->lineEdit->setText(s);
        }
}

void MainWindow::on_pushButton_25_clicked()//删除一个输入
{
    s=s.left(s.size()-1);
    ui->lineEdit->setText(s);
}
