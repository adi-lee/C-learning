#include "administrator.h"

administrator::administrator()
{

}
