#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H


class administrator
{
public:
    administrator();
};

#endif // ADMINISTRATOR_H
